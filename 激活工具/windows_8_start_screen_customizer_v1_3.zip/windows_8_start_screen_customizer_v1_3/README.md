Windows 8 Start Screen Customizer v1.3.6 beta
---------------------------------------------

This is a new version of this tool that will change your Windows 8 Start Screen background picture.

This tool doesn't need to edit your imageres.dll file anymore.


###New:
- You can set your desktop wallpaper as background picture (not support for multimonitor, it just uses the main monitor's desktop wallpaper)
- You can select your pictures from any folder and set it as a sequence of background pictures.
- There is a blur effect available, it is slow and slower on bigger resolutions, but it might work for you.
- Tiles opacity can now be changed (not perfect though)
- You can revert to default background

###Old and still available features:
- You can choose a picture and select the area to be shown as background picture.
- You can set the StartScreen transparency
- You can set the rows of you tiles (limited by your screen resolution)
- You can run it on startup hidden, so you can see your custom background as soon as this tool starts
- Save configuration to ini file.

Known bugs (kinda):
- On screen resolution change, StartScreen remains limited as the first resolution height, but it will try to fix it on resolution change.

As usual, unpack, rename to exe and run.

Written by vhanla -> http://apps.codigobit.info